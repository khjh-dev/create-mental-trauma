const vec3 N_TABLE[8] = vec3[8](
    vec3(2.9114, 2.9497, 2.5845),
    vec3(0.18299, 0.42108, 1.3734),
    vec3(1.3456, 0.96521, 0.61722),
    vec3(3.1071, 3.1812, 2.3230),
    vec3(0.27105, 0.67693, 1.3164),
    vec3(1.9100, 1.8300, 1.4400),
    vec3(2.3757, 2.0847, 1.8453),
    vec3(0.15943, 0.14512, 0.13547)
);

const vec3 K_TABLE[8] = vec3[8](
    vec3(3.0893, 2.9318, 2.7670),
    vec3(3.4242, 2.3459, 1.7704),
    vec3(7.4746, 6.3995, 5.3031),
    vec3(3.3314, 3.3291, 3.1350),
    vec3(3.6092, 2.6248, 2.2921),
    vec3(3.5100, 3.4000, 3.1800),
    vec3(4.2655, 3.7153, 3.1365),
    vec3(3.9291, 3.1900, 2.3808)
);

// Получение значения из таблицы через ручной if-else (без динамической индексации)
vec3 GetN(float idx) {
    float i = idx - 230.0;
    i = clamp(i, 0.0, 7.0);
    int index = int(floor(i));
    float t = i - float(index);
    
    vec3 n0, n1;
    if (index == 0) { n0 = N_TABLE[0]; n1 = N_TABLE[1]; }
    else if (index == 1) { n0 = N_TABLE[1]; n1 = N_TABLE[2]; }
    else if (index == 2) { n0 = N_TABLE[2]; n1 = N_TABLE[3]; }
    else if (index == 3) { n0 = N_TABLE[3]; n1 = N_TABLE[4]; }
    else if (index == 4) { n0 = N_TABLE[4]; n1 = N_TABLE[5]; }
    else if (index == 5) { n0 = N_TABLE[5]; n1 = N_TABLE[6]; }
    else if (index == 6) { n0 = N_TABLE[6]; n1 = N_TABLE[7]; }
    else { n0 = N_TABLE[7]; n1 = N_TABLE[7]; }
    
    return n0 + (n1 - n0) * t;
}

vec3 GetK(float idx) {
    float i = idx - 230.0;
    i = clamp(i, 0.0, 7.0);
    int index = int(floor(i));
    float t = i - float(index);
    
    vec3 k0, k1;
    if (index == 0) { k0 = K_TABLE[0]; k1 = K_TABLE[1]; }
    else if (index == 1) { k0 = K_TABLE[1]; k1 = K_TABLE[2]; }
    else if (index == 2) { k0 = K_TABLE[2]; k1 = K_TABLE[3]; }
    else if (index == 3) { k0 = K_TABLE[3]; k1 = K_TABLE[4]; }
    else if (index == 4) { k0 = K_TABLE[4]; k1 = K_TABLE[5]; }
    else if (index == 5) { k0 = K_TABLE[5]; k1 = K_TABLE[6]; }
    else if (index == 6) { k0 = K_TABLE[6]; k1 = K_TABLE[7]; }
    else { k0 = K_TABLE[7]; k1 = K_TABLE[7]; }
    
    return k0 + (k1 - k0) * t;
}

vec3 ComplexFresnel(float fresnel, float f0, float roughness) {
    float metalIdx = f0 * 255.0;
    vec3 k = GetK(metalIdx);
    vec3 n = GetN(metalIdx);
    
    k = max(k, vec3(0.001));
    n = max(n, vec3(0.001));
    
    float f = 1.0 - fresnel;
    float f2 = f * f;
    
    vec3 n2 = n * n;
    vec3 k2 = k * k;
    
    vec3 rs_num = n2 + k2 - 2.0 * n * f + f2;
    vec3 rs_den = n2 + k2 + 2.0 * n * f + f2;
    vec3 rs = rs_num / rs_den;
    
    vec3 rp_num = (n2 + k2) * f2 - 2.0 * n * f + 1.0;
    vec3 rp_den = (n2 + k2) * f2 + 2.0 * n * f + 1.0;
    vec3 rp = rp_num / rp_den;
    
    vec3 fresnel3 = 0.5 * (rs + rp);
    fresnel3 = clamp(fresnel3, vec3(0.0), vec3(1.0));
    
    return fresnel3;
}

vec3 ComplexFresnel(float fresnel, float f0) {
    return ComplexFresnel(fresnel, f0, 0.2);
}