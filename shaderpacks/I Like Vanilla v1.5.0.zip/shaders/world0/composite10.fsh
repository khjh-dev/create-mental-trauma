#version 140

#define SHADER_COMPOSITE10
#define OVERWORLD
#define FSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/composite10.glsl"
