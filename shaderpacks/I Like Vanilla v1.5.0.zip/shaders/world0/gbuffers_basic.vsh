#version 140

#define SHADER_GBUFFERS_BASIC
#define OVERWORLD
#define VSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/gbuffers_basic.glsl"
