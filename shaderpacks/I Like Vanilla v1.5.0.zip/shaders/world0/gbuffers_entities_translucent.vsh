#version 140

#define SHADER_GBUFFERS_ENTITIES_TRANSLUCENT
#define OVERWORLD
#define VSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/gbuffers_entities.glsl"
