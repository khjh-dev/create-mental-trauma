#version 120

// fog https://shaders.properties/current/guides/your-first-shaderpack/5_fog/

varying vec2 uv;

#define noiseAmount 0.05 // [0.0 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1] Amount of visual noise in the dark, caused IRL by constant, subtle electrical activity in neurons connecting to the eyes.
#define contrast 0.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 ] Brings the brightest brights (in the dark) closer to the darkest darks.
#define blurAmount 0.005 // [0.0 0.001 0.002 0.003 0.004 0.005 0.006 0.007 0.008 0.009 0.01 ] Blur in the dark, caused IRL by many rod-cells in the eyes having to "share" a fewer amount of neurotransmitters, increasing brightness but reducing detail.
#define darkestBlackIsEigengrau 1.0 // [0.0 1.0] Instead of true black, the darkest color you'll see is eigengrau (look it up).

uniform sampler2D colortex0;

uniform float frameTimeCounter;

float rand(vec2 co) {
   return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {

   vec3 original_color = texture2D(colortex0, uv).rgb;

   // blur (this also reduces sharpness so)
   vec3 blur_color = original_color;

   blur_color += texture2D(colortex0, uv + vec2(0.0, blurAmount)).rgb;
   blur_color += texture2D(colortex0, uv + vec2(blurAmount, 0.0)).rgb;

   blur_color += texture2D(colortex0, uv + vec2(0.0, blurAmount / 2.0)).rgb;
   blur_color += texture2D(colortex0, uv + vec2(blurAmount / 2.0, 0.0)).rgb;

   blur_color /= 5.0;

   // no more saturation
   float original_lum = dot(original_color, vec3(0.21, 0.72, 0.07));
   float dark_lum = dot(blur_color, vec3(0.21, 0.72, 0.07));

   // reduce contrast (luminance depth)
   float dark_value = dark_lum * contrast;

   // add noise
   dark_value += rand(uv + frameTimeCounter) * noiseAmount;

   // darkest color is now eigengrau
   vec3 dark_color = vec3(dark_value + vec3(22/255., 22/255., 29/255.) * darkestBlackIsEigengrau);

   // segregation of bright and non-bright areas
   float fac = 1.0 / (1.0 + pow(2.7, 40 * (0.2 - original_lum)));

   gl_FragColor = vec4(mix(dark_color, original_color, fac), 1.0f);
}